package com.capgemini.lms.exception;

public class FeedbackNotFoundException extends Exception{
	private static final long serialVersionUID = 1L;

}

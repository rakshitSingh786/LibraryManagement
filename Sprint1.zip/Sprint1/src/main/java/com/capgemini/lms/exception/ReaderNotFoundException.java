package com.capgemini.lms.exception;

public class ReaderNotFoundException  extends Exception{
	private static final long serialVersionUID = 1L;

}
